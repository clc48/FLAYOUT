public class ECar extends Car{
	private double mpw;
	private double batteryHolds;
	private double batteryHas;



	public ECar(double mpw, double batteryCapacity, double batteryInCar, double numMiles){
		super(numMiles);
		this.mpw=mpw;
		batteryHas=batteryCapacity;
		batteryHolds=batteryInCar;
		}
		
		 public void fillToCapacity(){
  	if (batteryHas<batteryHolds/2){
  		batteryHas=batteryHolds;}	
  	}
public void drive (double numMiles){
	double Mileage= getMileage();
	if (batteryHas >= numMiles/mpw){
	batteryHas = batteryHas - (numMiles/mpw);
	Mileage = Mileage + numMiles;
	}else{
	Mileage += Mileage + mpw * batteryHas;
		batteryHas= 0;	
			
   }
   setMileage(Mileage);
	}	
	}

	
