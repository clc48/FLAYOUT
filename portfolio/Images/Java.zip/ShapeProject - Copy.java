/**
 * @(#)ShapeProject.java
 *
 * ShapeProject application
 *
 * @author 
 * @version 1.00 2017/2/23
 */
 
public class ShapeProject {
    
    public static void main(String[] args) {
   
     Circle myShape1= new Circle();
     myShape1.setRadius(-1);
     myShape1.computeArea();
     myShape1.computePerimeter();
   System.out.println(myShape1);
   
   
   System.out.println();
    
    
     Rectangle myShape2 = new Rectangle();
     myShape2.setLength(20);
     myShape2.setWidth(15);
     myShape2.computeArea();
     myShape2.computePerimeter();
     	System.out.println(myShape2);
     
    Square myShape3 = new Square();
    myShape3.setLength(20);
    myShape3.computeArea();
    myShape3.computePerimeter();
    System.out.println(myShape3);
    
    
    
    	
    
    }
    
    
}
