public class GasOperatedCar extends Car{
	private double mpg;
	private double gasTankHolds;
	private double gasTankHas;
	
	public GasOperatedCar(double mpg, double gasTankHolds, double gasTankHas){
		this.mpg=mpg;
		gasTankHolds=tankCappacity;
		gasTankHas=gasInTank;
		this.numMiles=numMiles;
	}
	
}