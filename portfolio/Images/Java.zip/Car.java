
 public Abstract Class Car {
 	private double mileage;
 
 	 public car(double mileage)
 	 {
 	 	this.mileage=mileage
 	 	}
 	 	
 	 public Abstract void fillToCapacity();
 	 public Abstract void drive(double numMiles){
 	 	drive=numMiles;
 	 }
 
 }
 	
 	