 public class Rectangle implements IShape{
 	private double length;
 	private double width;
 	
 	public Rectangle(){
 	}
 	public Rectangle( double length, double width){
 		setLength(length);
 		setWidth(width);
 	}
 	public void setLength(double length){
 		this.length=length;
 	}
 		public double getLength(){
 		return this.length;
 	}
 	public void setWidth(double width){
 		this.width=width;
 	}
   public  double getWidth(){
   	return this.width;
   }
   public double computeArea(){
   	return this.length * this.width;
   }
   public double computePerimeter(){
   	 return ( 2 * this.length+  2 * this.width);
   }
    public String toString(){
 	 	StringBuffer sb = new StringBuffer();
 	 	
 	 	sb.append("This is a Rectangle" + "\n");
 	 	sb.append("Width = " +getWidth() + "\n");
 	 	sb.append("Length = " + getLength()+ "\n");
 	 	sb.append("Area = " +getWidth()*getLength()+"\n");
 	 	sb.append("Perimeter = " +(2*getWidth() + 2 * getLength()) + "\n");
 	 	  return sb.toString();
 	 }
 }