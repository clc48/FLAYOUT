/**
 * @(#)CarProject.java
 *
 * CarProject application
 *
 * @author 
 * @version 1.00 2017/2/10
 */
 
public class CarProject {
    
    public static void main(String[] args) {
    	
    	// TODO, add your application code
    	System.out.println("Hello World!");
    }
}
