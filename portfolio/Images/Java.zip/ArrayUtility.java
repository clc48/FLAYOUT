/**
 * @(#)ArrayUtility.java
 *
 *
 * @author 
 * @version 1.00 2016/12/9
 */
/**
 * @(#)ArrayUtility.java
 *
 *
 * @author 
 * @version 1.00 2016/12/5
 */


public class ArrayUtility {
  public static void selectionSort (int[] numbers)
   	 {
   	 	int min, temp;
   	 	for (int index=0; index < numbers.length-1; index++)
   	 	{
   	 		min = index;
   	 		for(int scan = index+1; scan < numbers.length; scan++)
   	 			if (numbers[scan] < numbers[min])
   	 				min = scan;
   	 					
   	 			temp = numbers[min];
   	 			numbers[min] = numbers[index];
   	 			numbers[index] = temp;
   	 	}
   	 }  
	public static int binarySearch(int[] numbers, int target)
   {
   	int low = 0, high = numbers.length-1, middle = (low + high) / 2;
   		  
   		  while (numbers[middle] != target && low <= high)
   		  {
   		  	if (target < numbers[middle])
   		  	   high = middle - 1;
   		  	   else
   		  			low = middle + 1;
   		  			middle = (low + high) / 2;
   		  		}
   		  		if (numbers[middle] == target)
   		  			return middle;
   		  		else
   		  			return -1;
   		  	 }
   	
   	   
  			
    public ArrayUtility() {
    }
    
   public double getAverage(int[] list) {
 	
 	double total = 0.0;
 	for (int i = 0; i < list.length; i++) {
 		total = total + list[i];
 	}
 	
 	 return total/list.length;
  }
  
  
  public int findFirstPosition(int[] list, int target) {
  
 int positionInArray1 = -1;


for (int i = 0; i < list.length; i++) {
if (list[i] == target) {
	positionInArray1 = i;
	i = list.length;
        }
}
	return positionInArray1;
  }
  	
  public int findLastPosition(int[] list, int target) {
 
 
	int positionInArray2 = -1;

for (int i = 0; i < list.length; i++) {
	if (list[i] == target) {
	positionInArray2 = i;
        }
  }
  return positionInArray2;
  }
  
  public int findNumberOfOccurrences(int[] list, int target){
  	
	int counter = 0;

  for (int i = 0; i < list.length; i++) {
	if (list[i] == target) {
	counter ++;
        }
  }
  return counter;
  	
  	
  	}
  
  public boolean existMultipleTimes(int[] list, int target){
  	
  int counter = findNumberOfOccurrences(list, target);
  
  if (counter > 1){
  	return true;
  }else{
  	return false;
  }
 
  
}
  }


   
  	 
    
   
  
 