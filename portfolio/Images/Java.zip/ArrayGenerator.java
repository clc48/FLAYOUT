/**
 * @(#)ArrayGenerator.java
 *
 *
 * @author 
 * @version 1.00 2016/12/5
 */
import java.util.Random;

public class ArrayGenerator {
	
 
	private int randomNumberListSize;
	private int randomNumberRange;
	private int[] listOfNumbers;

   public ArrayGenerator() {
    }
     
    public ArrayGenerator(int size, int range){
     
     this.setRandomNumberListSize(size);
    this.setRandomNumberRange(range);
	this.createListOfNumbers(size,range);
     }

    
    public void setRandomNumberListSize (int size){
    	this.randomNumberListSize = size;
    }
   
    public int getRandomNumberSize(){
	return randomNumberListSize;
	}
  
    public void setRandomNumberRange (int range){
        this.randomNumberRange = range;}

		public int getRandomNumberRange(){
	return randomNumberRange;
	}
	public int [] getListOfNumbers(){
		return listOfNumbers;
	}
	
	private void createListOfNumbers (int size, int range){
		listOfNumbers = new int [size];
		
			Random generator = new Random();
			 
			 for (int i = 0; i < listOfNumbers.length; i++){
			 	listOfNumbers[i] = generator.nextInt(range);
			 
		ArrayGenerator <Integer> listOfNumbers= new ArrayGenerator<Integer>(20);
    		for (int i=0; i<20; i++);
    		{
    			listOfNumbers.add(i);
    			}
    		collections.sort(listOfNumbers);
    		String[] randomNumber= (String[])listOfNumbers.toArray();
    			for(int i=0; 1<20;i++) {
    				System.out.Println(randomNumbers[i] + "<b>"); 
    			


 }	
 }
 }

