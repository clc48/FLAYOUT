/**
 * @(#)MyArrayProject.java
 *
 * MyArrayProject application
 *
 * @author 
 * @version 1.00 2016/12/5
 */
 	
public class MyArrayProject {
    
    public static void main(String[] args) {
    	
 ArrayGenerator generator = new ArrayGenerator (20, 10);
 
 int[] list = generator.getListOfNumbers();
 for (int i = 0; i < list.length; i++){
 	
 	System.out.println(list[i]);
 }
 
   ArrayUtility utility = new ArrayUtility (); 
  /*double average = utility.getAverage(list); 
 	System.out.println(" Average is " + utility.getAverage(list));
 
 int firstOccurrence = utility.findFirstPosition(list, 3);	
 	System.out.println(" First position is " + utility.findFirstPosition(list, 3));
 	
 int lastOccurrence = utility.findLastPosition(list, 8);
 System.out.println(" Last postition is " + utility.findLastPosition(list, 8));
 
 int numberOfOccurrences = utility.findNumberOfOccurrences(list, 2);
  System.out.println(" It occured  at index " + utility.findNumberOfOccurrences(list, 2));
   */
utility.selectionSort (list);
 System.out.println("After Sorting");
  for (int i = 0; i < list.length; i++){
 	
 	System.out.println(list[i]);}
 	
   int binarySearch = utility.binarySearch(list, 8);
   	System.out.println("8 is in the index " + utility.binarySearch(list, 8));

    } 
}