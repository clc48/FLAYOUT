/**
 * @(#)MyScannerProject.java
 *
 *
 * @author 
 * @version 1.00 2016/10/31
 */

import java.util.Scanner;
   import java.util.InputMismatchException;
   import java.text.NumberFormat;
   import java.text.DecimalFormat;
   
public class MyScannerProject {

     public static void main(String[] args){
     
   
   
   
  Scanner scan= new Scanner (System.in);
 

 
 int i;
  System.out.println("Enter Integer");
  i = scan.nextInt();
  System.out.println("You've entered:" + i);
  
  double d1;
  	System.out.println("Enter double");
  d1= scan.nextDouble();
  System.out.println("You've entered:" + d1);
  
  NumberFormat percent = NumberFormat.getPercentInstance();
  NumberFormat dollar = NumberFormat.getCurrencyInstance();
  
  Scanner scan2= new Scanner (System.in);
  String s1;
   System.out.println(" Declare whether you are using currency or percent");
    s1= scan2.nextLine();
    if (s1.equals("percent"))
    	{
	System.out.println(percent.format(d1 + i));
	}
	else
  if (s1.equals("currency")){
  
	System.out.println( dollar.format(d1 * i));
}else{
   System.out.println("Invlaid Input");
}




    }
}
