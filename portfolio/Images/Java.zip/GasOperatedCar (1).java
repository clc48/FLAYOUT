public class GasOperatedCar extends Car{
	private double mpg;
	private double gasTankHolds;
	private double gasTankHas;
	
	public GasOperatedCar(double mpg, double tankCapacity, double gasInTank, double numMiles){
		super (numMiles);
		this.mpg=mpg;
		gasTankHolds=tankCapacity;
		gasTankHas=gasInTank;
	   
	}
	
  public void fillToCapacity(){
  	if (gasTankHas<gasTankHolds/2){
  		gasTankHas=gasTankHolds;}	
  	}
  	
 	  
public void drive (double numMiles){
	 double Mileage= getMileage();
	 
	if(numMiles < mpg * gasTankHas)
		{ Mileage += numMiles;
   gasTankHas = gasTankHas-numMiles;
   }else{
   	Mileage = Mileage +(mpg * gasTankHas);
   	gasTankHas=0;
   }
   setMileage(Mileage);
}
}

  