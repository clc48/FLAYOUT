
   public interface IShape{
   	public double computePerimeter();
   	public double computeArea();
   }
