/**
 * @(#)MyWrappingProject.java
 *
 * MyWrappingProject application
 *
 * @author 
 * @version 1.00 2016/10/21
 */
 
public class MyWrappingProject {
    
    public static void main(String[] args) {
    	
    	// TODO, add your application code
    	System.out.println("Hello World!");



int i= (25);
int j= (10);
double d1= (25.0);
double d2= (10.0);


System.out.println(i*j);
System.out.println(i-j);
System.out.println(i+j);
System.out.println(i/j);
System.out.println((double)1/j);
System.out.println(d1*d2);
System.out.println(d1/d2);
System.out.println((int)d1/d2);
System.out.println(Math.pow(i,j));

double a1=18.18;
double a2=18.17;

if (a1==a2){ 
System.out.println("same double");
 }else{
	System.out.println("different double");
 }
 
 String s= ("Computer");
 String s1=("Computer");

	if(s.equals(s1)) {
		System.out.println("same");
		}else{
		System.out.println("different");
	}
 String C1= new String("APEnglish");
 String C2= new String("Physics");

  if (C1.compareTo(C2)==0) {
  	System.out.println("True");
  }else{System.out.println("False");
  }
  
 int counter = 10;
double sum = 25.00;

System.out.println(sum/counter); 


int i1= 10;
 int j1 = 3;
 	
 	System.out.println((double)i1/j1);
}
    

   
   
   
   
   
   
   
   
   
    }
