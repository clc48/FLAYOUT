/**
 * @(#)PersonalProject.java
 *
 *
 * @author 
 * @version 1.00 2016/12/9
 */
public class Contact implements Comparable {
private String firstName;
private String lastName;
private String phone; 

public Contact (String first, String last, String telephone) {
	firstName = first;
lastName = last;
phone = telephone;

}

public String toString () {

return lastName 
+ "," + firstName 
+ "\t" + phone;
}

public int compareTo (Object other) { 
	int result; 
	if (lastName.equals(((Contact)other).lastName)){
	
		result = firstName.compareTo(((Contact)other).firstName);
	}else{
	
	result = lastName.compareTo(((Contact)other).lastName);}
return result;

//* Without implentments Comaprable, the class contact cannot implement the interface at my ArrayUtility and MyArrayProject
}
}